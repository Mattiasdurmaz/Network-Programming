# Lab 6 - HTTP Request part 1




import socket


HOST =""
PORT = 8080
ENC = "ascii"


def main():

    #skapa socket (ipv4, tcp)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(5)
    print(f"Server runnig on port {PORT}...(open http://localhost:{PORT}/)")

    while True:
        conn, addr = server.accept()
        print(f"\nConnection from {addr}")
        data = conn.recv(1024).decode(ENC, errors="ignore")
        if data:
           print("----Client Request Start----")
           print(data)
           print("----Client Request End----")
           conn.close()


if __name__ == "__main__":
    main()

